<?PHP
include'../config/config1.php';

?>